#ifndef LORS_MISC_H
#define LORS_MISC_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#define LORS_MIN_TIMEOUT 20
/*#define D_LORS_NONE    0x0000*/
/*#define D_LORS_TERSE   0x0001*/
/*#define D_LORS_ERR_MSG 0x0002 */
/*#define D_LORS_VERBOSE (0x0004|D_LORS_TERSE|D_LORS_ERR_MSG) */

/*extern int g_db_level;*/

/*extern void lorsDebugPrint(int db_level, char *format, ... );*/

#endif /* LORS_MISC_H */
