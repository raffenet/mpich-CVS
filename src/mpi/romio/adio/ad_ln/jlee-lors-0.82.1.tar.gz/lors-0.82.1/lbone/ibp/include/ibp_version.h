#ifndef _IBP_VERSION_H
#define _IBP_VERSION_H

#define IBP_VER_MAJOR "1.4"
#define IBP_VER_MINOR "0.2"

#endif
