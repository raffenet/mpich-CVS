/* ngc.h */

#ifndef __NGC_H__
#define __NGC_H__


char **getLatLong (char **args);


#endif /* __NGC_H__ */
