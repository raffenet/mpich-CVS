/* $Id: forecasters.h,v 1.3 1999/09/22 16:54:46 hayes Exp $ */

#include "last_value.h"
#include "exp_smooth.h"
#include "median.h"
#include "run_mean.h"
