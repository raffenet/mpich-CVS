#ifndef _IBP_VERSION_H
#define _IBP_VERSION_H

#define IBP_VER_MAJOR "1.3.1"
#define IBP_VER_MINOR ""

#endif
