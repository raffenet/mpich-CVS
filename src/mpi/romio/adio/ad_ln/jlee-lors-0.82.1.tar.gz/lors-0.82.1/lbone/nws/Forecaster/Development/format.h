/* $Id: format.h,v 1.1.1.1 1998/01/16 23:59:45 jhayes Exp $ */

#define TSFIELD 1
#define VALFIELD 2


