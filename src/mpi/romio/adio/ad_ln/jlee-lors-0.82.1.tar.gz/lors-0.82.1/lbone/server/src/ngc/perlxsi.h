#ifndef __PERLXSI_H__
#define __PERLXSI_H__


#include <EXTERN.h>
#include <perl.h>


EXTERN_C void xs_init (pTHXo);


#endif /* __PERLXSI_H__ */
