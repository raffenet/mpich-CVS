#include <stdio.h>
#include "../include/ibp_nfu_para.h"
#include "../include/ibp_protocol.h"

int do_ping2(int npara , NFU_PARA *paras){
  	char command[256];
	char *tmpc, *dest, *line;
    char buf[128];
	int reps;
	FILE *fp;

    if(npara != 3){
        return (-1);
    };

	dest = (char *)(paras[0].data);
	reps = *((int *)(paras[1].data));
	line = (char *)(paras[2].data);
    reps = ntohl(reps);

  	sprintf(command,"/bin/ping -c %d %s\n", reps+1, dest);

  	if((fp = popen(command, "r")) == NULL) {
    	perror("popen failed");
    	return(IBP_E_INTERNAL);
  	}

  	while(fgets(buf, paras[2].len, fp) != NULL) {
		if(strstr(buf, "min/avg/max") != NULL) {
      		if((tmpc = strchr(buf, '\n')) != NULL) {
          		*tmpc = '\0';
      		}
			memcpy(line, buf, 128);
			break;
    	}
	}

    return (0);
}
